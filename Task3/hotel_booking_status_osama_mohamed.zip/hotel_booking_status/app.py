# app.py
from flask import Flask, request, render_template, jsonify
import joblib
import numpy as np
import pandas as pd
from datetime import datetime

app = Flask(__name__)

# Load model and scaler
model = joblib.load('rf_classifier.pkl')
scaler = joblib.load('Scalar.pkl')

# Configuration
FEATURE_ORDER = [
    'number of adults', 'number of children', 'number of weekend nights',
    'number of week nights', 'type of meal', 'car parking space',
    'room type', 'lead time', 'market segment type', 'repeated', 'P-C',
    'P-not-C', 'average price ', 'special requests',
    'year of reservation', 'month of reservation', 'day of reservation'
]

MAPPINGS = {
    'meal': {
        'Meal Plan 1': 0, 'Meal Plan 2': 1, 
        'Meal Plan 3': 2, 'Not Selected': 3
    },
    'room': {
        'Room_Type 1': 0, 'Room_Type 2': 1, 'Room_Type 3': 2,
        'Room_Type 4': 3, 'Room_Type 5': 4, 'Room_Type 6': 5,
        'Room_Type 7': 6
    },
    'market': {
        'Online': 0, 'Offline': 1, 'Corporate': 2,
        'Complementary': 3, 'Aviation': 4
    }
}

def prepare_features(form_data):
    """Convert form data to properly formatted DataFrame"""
    # Date handling
    try:
        reservation_date = datetime.strptime(
            form_data['reservation_date'], '%Y-%m-%d'
        )
    except (ValueError, KeyError):
        raise ValueError("Invalid or missing date (use YYYY-MM-DD format)")
    
    # Build features dictionary
    features = {
        'number of adults': int(form_data.get('number_of_adults', 0)),
        'number of children': int(form_data.get('number_of_children', 0)),
        'number of weekend nights': int(form_data.get('number_of_weekend_nights', 0)),
        'number of week nights': int(form_data.get('number_of_week_nights', 0)),
        'type of meal': MAPPINGS['meal'].get(
            form_data.get('type_of_meal', 'Not Selected'), 3
        ),
        'car parking space': int(form_data.get('car_parking_space', 0)),
        'room type': MAPPINGS['room'].get(
            form_data.get('room_type', 'Room_Type 1'), 0
        ),
        'lead time': int(form_data.get('lead_time', 0)),
        'market segment type': MAPPINGS['market'].get(
            form_data.get('market_segment_type', 'Online'), 0
        ),
        'repeated': int(form_data.get('repeated', 0)),
        'P-C': int(form_data.get('p_c', 0)),
        'P-not-C': int(form_data.get('p_not_c', 0)),
        'average price ': float(form_data.get('average_price ', 0.0)),
        'special requests': int(form_data.get('special_requests', 0)),
        'year of reservation': reservation_date.year,
        'month of reservation': reservation_date.month,
        'day of reservation': reservation_date.day
    }

    # Create DataFrame with correct feature order
    features_df = pd.DataFrame([features], columns=FEATURE_ORDER)

    # Apply scaling
    scaled_features = scaler.transform(features_df[['average price ', 'lead time']])
    features_df[['average price ', 'lead time']] = scaled_features

    return features_df

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        features_df = prepare_features(request.form)
        prediction = model.predict(features_df)[0]
        result = 'Canceled' if prediction == 1 else 'Not Canceled'
        return jsonify({
            'prediction': result,
            'status': 'success',
            'features_used': features_df.iloc[0].to_dict()
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e),
            'status': 'error'
        }), 400

if __name__ == '__main__':
    app.run(debug=True)