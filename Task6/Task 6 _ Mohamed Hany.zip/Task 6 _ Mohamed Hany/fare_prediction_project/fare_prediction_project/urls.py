from django.contrib import admin
from django.urls import path, include
from fare_prediction_app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('predict/', include('fare_prediction_app.urls')),
    path('', views.home, name='home'),  # Root path
]