import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import joblib

# Load the dataset
data = pd.read_csv(r"C:\Users\fdrha\OneDrive\Desktop\Cellula\Task 4_ Mohamed hany\final_internship_data.csv")

# Preprocess the data
data.dropna(inplace=True)
data.drop(['User ID', 'User Name', 'Driver Name', 'key', 'pickup_datetime'], axis=1, inplace=True)

# Convert categorical variables to numerical
data = pd.get_dummies(data, columns=['Car Condition', 'Weather', 'Traffic Condition'], drop_first=True)

# Define features and target
X = data.drop('fare_amount', axis=1)
y = data['fare_amount']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the Linear Regression model
lr = LinearRegression()
lr.fit(X_train, y_train)

# Evaluate the model
y_pred = lr.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Linear Regression - MSE: {mse}, R2: {r2}")

# Save the model
joblib.dump(lr, 'linear_regression_model.pkl')

# Print the columns for reference
print("Training data columns:", X_train.columns.tolist())