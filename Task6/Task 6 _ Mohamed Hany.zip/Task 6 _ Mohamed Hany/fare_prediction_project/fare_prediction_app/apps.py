from django.apps import AppConfig


class FarePredictionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fare_prediction_app'
