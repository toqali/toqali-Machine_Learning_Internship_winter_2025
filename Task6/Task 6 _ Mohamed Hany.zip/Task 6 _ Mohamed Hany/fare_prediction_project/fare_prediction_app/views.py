import os
import joblib
from django.shortcuts import render
import pandas as pd

# Define the path to the model file
model_path = os.path.join(os.path.dirname(__file__), 'models', 'linear_regression_model.pkl')

# Load the model
if os.path.exists(model_path):
    model = joblib.load(model_path)
else:
    raise FileNotFoundError(f"Model file not found at: {model_path}")

def home(request):
    return render(request, 'fare_prediction_app/home.html')

def predict(request):
    if request.method == 'POST':
        # Get input data from the form
        input_data = {
            'distance': float(request.POST['distance']),
            'month': float(request.POST['month']),
            'weekday': float(request.POST['weekday']),
            'year': float(request.POST['year']),
            'Car Condition': request.POST['car_condition'],
            'Weather': request.POST['weather'],
            'Traffic Condition': request.POST['traffic_condition'],
        }

        # Convert input data to a DataFrame
        input_df = pd.DataFrame([input_data])

        # One-hot encode categorical variables
        input_df = pd.get_dummies(input_df, columns=['Car Condition', 'Weather', 'Traffic Condition'], drop_first=True)

        # Ensure the input DataFrame has the same columns as the training data
        # Add missing columns with default value 0
        expected_columns = [
            'distance', 'month', 'weekday', 'year',
            'Car Condition_Good', 'Car Condition_Excellent',
            'Weather_Rainy', 'Weather_Stormy',
            'Traffic Condition_Heavy Traffic', 'Traffic Condition_Dense Traffic'
        ]
        for col in expected_columns:
            if col not in input_df.columns:
                input_df[col] = 0

        # Reorder columns to match the training data
        input_df = input_df[expected_columns]

        # Convert input data to numpy array and reshape
        input_data = input_df.to_numpy().reshape(1, -1)

        # Make prediction
        prediction = model.predict(input_data)

        # Render the result
        return render(request, 'fare_prediction_app/result.html', {'prediction': prediction[0]})

    return render(request, 'fare_prediction_app/predict.html')