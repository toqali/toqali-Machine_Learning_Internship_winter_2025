import joblib
from django.shortcuts import render
from django.http import JsonResponse
import os

# Load the model
model_path = os.path.join(os.path.dirname(__file__), 'decision_tree_model.joblib')
model = joblib.load(model_path)

def predict_fare(request):
    if request.method == 'POST':
        # Extract input features from the request
        car_condition = float(request.POST.get('car_condition'))
        weather = float(request.POST.get('weather'))
        traffic_condition = float(request.POST.get('traffic_condition'))
        pickup_longitude = float(request.POST.get('pickup_longitude'))
        pickup_latitude = float(request.POST.get('pickup_latitude'))
        dropoff_longitude = float(request.POST.get('dropoff_longitude'))
        dropoff_latitude = float(request.POST.get('dropoff_latitude'))
        passenger_count = int(request.POST.get('passenger_count'))
        hour = int(request.POST.get('hour'))
        day = int(request.POST.get('day'))
        weekday = int(request.POST.get('weekday'))
        year = int(request.POST.get('year'))
        jfk_dist = float(request.POST.get('jfk_dist'))
        ewr_dist = float(request.POST.get('ewr_dist'))
        lga_dist = float(request.POST.get('lga_dist'))
        sol_dist = float(request.POST.get('sol_dist'))
        nyc_dist = float(request.POST.get('nyc_dist'))
        distance = float(request.POST.get('distance'))
        bearing = float(request.POST.get('bearing'))
        haversine_distance = float(request.POST.get('haversine_distance'))

        # Prepare input features for the model
        input_features = [
            [
                car_condition, weather, traffic_condition,
                pickup_longitude, pickup_latitude,
                dropoff_longitude, dropoff_latitude,
                passenger_count, hour, day, weekday, year,
                jfk_dist, ewr_dist, lga_dist, sol_dist, nyc_dist,
                distance, bearing, haversine_distance
            ]
        ]

        # Make prediction
        predicted_fare = model.predict(input_features)[0]

        # Return the prediction as JSON
        return JsonResponse({'predicted_fare': predicted_fare})
    return render(request, 'fare_prediction/index.html')