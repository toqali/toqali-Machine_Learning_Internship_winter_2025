import pickle
import numpy as np
from django.shortcuts import render
from django.http import JsonResponse

# Load the trained model
model_path = "predictor/lgb_model.pkl"
with open(model_path, "rb") as file:
    model = pickle.load(file)


def predict_fare(request):
    if request.method == "POST":
        try:
            # Extract input values from form submission
            features = [
                float(request.POST.get("car_condition")),
                float(request.POST.get("weather")),
                float(request.POST.get("traffic_condition")),
                float(request.POST.get("pickup_longitude")),
                float(request.POST.get("pickup_latitude")),
                float(request.POST.get("dropoff_longitude")),
                float(request.POST.get("dropoff_latitude")),
                int(request.POST.get("passenger_count")),
                int(request.POST.get("hour")),
                int(request.POST.get("day")),
                int(request.POST.get("month")),
                int(request.POST.get("weekday")),
                int(request.POST.get("year")),
                float(request.POST.get("jfk_dist")),
                float(request.POST.get("ewr_dist")),
                float(request.POST.get("lga_dist")),
                float(request.POST.get("sol_dist")),
                float(request.POST.get("nyc_dist")),
                float(request.POST.get("distance")),
                float(request.POST.get("bearing")),
            ]

            # Convert to NumPy array
            input_data = np.array([features])

            # Predict fare
            predicted_fare = model.predict(input_data)[0]

            return JsonResponse({"predicted_fare": predicted_fare})

        except Exception as e:
            return JsonResponse({"error": str(e)})

    return render(request, "index.html")
